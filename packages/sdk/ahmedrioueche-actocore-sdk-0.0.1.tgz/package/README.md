# @ahmedrioueche/actocore-sdk

Embeddable React chat SDK for ActoCore projects.

## Install

```bash
npm install @ahmedrioueche/actocore-sdk
```

## Quick start

```tsx
import { ActocoreProvider, ActoChat } from '@ahmedrioueche/actocore-sdk';
import '@ahmedrioueche/actocore-sdk/styles.css';

export function App() {
  return (
    <ActocoreProvider
      apiKey={import.meta.env.VITE_ACTOCORE_API_KEY}
      baseURL={import.meta.env.VITE_ACTOCORE_API_URL}
      i18n={{ locale: 'en' }}
      theme={{ mode: 'light' }}
      security={{ allowedActionNames: ['deploy'], enforceActionAllowlist: true }}
      ui={{ showSources: true, showIntentBadge: true }}
      actions={{
        deploy: async (input) => {
          console.log('deploy action payload', input);
        },
      }}
    >
      <ActoChat />
    </ActocoreProvider>
  );
}
```

## Configuration

- `apiKey` (required): project SDK/API key from ActoCore.
- `baseURL` (optional): Core URL (example `http://localhost:3000`).
- `apiVersion` (optional): API prefix version.
- `i18n.locale`: current language (`en`, `fr`, ...).
- `i18n.translations`: deep overrides for SDK copy without forking UI.
- `theme.mode`: `light` | `dark` | `system`.
- `theme.tokens`: token overrides mapped to `--ac-*` CSS vars.
- `security.allowedActionNames`: allowlist for executable actions.
- `security.enforceActionAllowlist`: block non-allowlisted actions.
- `ui.showSources`, `ui.showIntentBadge`, `ui.composerMinRows`, `ui.composerMaxRows`.

## i18n rule

All user-facing SDK text must be translated through i18n keys. Do not hardcode user copy in components.

## Theming rule

Use design tokens only (`var(--ac-*)`) for colors, spacing, typography, radii, and layout constants.

## Security rule

Core validates action schemas. SDK additionally enforces the host allowlist before invoking handlers.

